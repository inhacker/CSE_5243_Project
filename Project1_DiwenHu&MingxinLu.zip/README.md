Run:
in terminal: 
python main.py
(Due to python is a kind of dynamic language, we don't need Makefile.)

Submission: 
.sgm: data set.
main.py?all codes with comments.

After running, you could get the output.txt with featured vectors and topics. That is our result.
